'use strict';
document.addEventListener('DOMContentLoaded', async () => {
    const $ = i => document.getElementById(i);
    const setText = (i, t) => { const e = $(i); if (e) e.textContent = t };
    const views = { s: $('setupView'), m: $('mainView') };
    const apiInput = $('apiKeyInput');
    const syncToggle = $('syncToggle');
    const verifyBtn = $('verifyBtn');
    const changeKeyBtn = $('changeKeyBtn');
    const toggleKeyBtn = $('toggleKey');
    const viewFailedBtn = $('viewFailedBtn');
    const solveStatusEl = $('solveStatus');
    const themeToggle = $('themeToggle');
    const changelogModal = $('changelogModal');
    const closeChangelogBtn = $('closeChangelog');
    const rateLimitWarning = $('rateLimitWarning');

    // Show changelog if needed
    async function checkChangelog() {
        try {
            const d = await chrome.storage.local.get(['show_changelog']);
            if (d.show_changelog && changelogModal) {
                changelogModal.style.display = 'flex';
                await chrome.storage.local.set({ show_changelog: false });
            }
        } catch (e) { }
    }
    checkChangelog();

    // Close changelog modal
    if (closeChangelogBtn) {
        closeChangelogBtn.addEventListener('click', () => {
            if (changelogModal) changelogModal.style.display = 'none';
        });
    }

    // Apply saved theme
    async function applyTheme() {
        try {
            const d = await chrome.storage.local.get(['light_mode']);
            if (d.light_mode) {
                document.body.classList.add('light');
                if (themeToggle) themeToggle.textContent = '◑';
            }
        } catch (e) { }
    }
    applyTheme();

    // Theme toggle (button click)
    if (themeToggle) {
        themeToggle.addEventListener('click', async () => {
            const isLight = document.body.classList.toggle('light');
            themeToggle.textContent = isLight ? '◑' : '◐';
            await chrome.storage.local.set({ light_mode: isLight });
        });
    }

    const showView = main => {
        if (views.s && views.m) {
            views.s.style.display = main ? 'none' : 'block';
            views.m.style.display = main ? 'block' : 'none';
        }
    };

    // Eye toggle for show/hide password
    if (toggleKeyBtn && apiInput) {
        toggleKeyBtn.addEventListener('click', () => {
            const isPassword = apiInput.type === 'password';
            apiInput.type = isPassword ? 'text' : 'password';
            toggleKeyBtn.style.color = isPassword ? '#fff' : 'rgba(255,255,255,0.5)';
        });
    }

    // Validate API key with real call
    async function validateKey(key) {
        try {
            const res = await fetch('https://api.groq.com/openai/v1/models', {
                headers: { 'Authorization': `Bearer ${key}` }
            });
            return res.ok;
        } catch (e) {
            return false;
        }
    }

    // Update status display
    function updateStatusDisplay(status, time) {
        if (!solveStatusEl) return;
        solveStatusEl.className = 'solve-status ' + (status || 'idle');
        if (status === 'solving') {
            solveStatusEl.textContent = 'Solving...';
        } else if (status === 'success' && time) {
            solveStatusEl.textContent = `Solved in ${time}s`;
        } else if (status === 'failed') {
            solveStatusEl.textContent = 'Failed';
        } else {
            solveStatusEl.textContent = 'Idle';
        }
    }

    // Initial load
    try {
        const d = await chrome.storage.local.get(['groq_api_key', 'solved_count', 'manual_mode', 'solve_status', 'solve_time', 'failed_captchas']);
        if (d.groq_api_key) {
            showView(true);
            setText('solvedCount', d.solved_count || 0);
            setText('failedCount', (d.failed_captchas || []).length);
            updateStatusDisplay(d.solve_status, d.solve_time);
        } else {
            showView(false);
        }
        if (syncToggle) syncToggle.checked = !(d.manual_mode === true);
    } catch (e) { }

    // Sync toggle
    if (syncToggle) {
        syncToggle.addEventListener('change', async e => {
            await chrome.storage.local.set({ manual_mode: !e.target.checked });
        });
    }

    // Connect button with validation
    if (verifyBtn) {
        verifyBtn.addEventListener('click', async () => {
            if (!apiInput) return;
            const key = apiInput.value.trim();

            if (!key.startsWith('gsk_')) {
                setText('setupError', 'Invalid Key Format');
                return;
            }

            verifyBtn.textContent = 'Validating...';
            verifyBtn.disabled = true;
            setText('setupError', '');

            const valid = await validateKey(key);

            if (valid) {
                await chrome.storage.local.set({ groq_api_key: key });
                showView(true);
            } else {
                setText('setupError', 'Invalid API Key');
            }

            verifyBtn.textContent = 'Connect';
            verifyBtn.disabled = false;
        });
    }

    // Change key button
    if (changeKeyBtn) {
        changeKeyBtn.addEventListener('click', async () => {
            await chrome.storage.local.remove('groq_api_key');
            showView(false);
            if (apiInput) apiInput.value = '';
        });
    }

    // View failed captchas
    if (viewFailedBtn) {
        viewFailedBtn.addEventListener('click', async () => {
            try {
                const d = await chrome.storage.local.get(['failed_captchas']);
                const failed = d.failed_captchas || [];
                if (failed.length === 0) {
                    alert('No failed captchas recorded!');
                    return;
                }
                // Show in a new tab as JSON
                const blob = new Blob([JSON.stringify(failed, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                chrome.tabs.create({ url });
            } catch (e) {
                alert('Error loading failed captchas');
            }
        });
    }

    // Update stats periodically
    setInterval(async () => {
        try {
            const d = await chrome.storage.local.get(['solved_count', 'solve_status', 'solve_time', 'failed_captchas', 'rate_limit_warning']);
            setText('solvedCount', d.solved_count || 0);
            setText('failedCount', (d.failed_captchas || []).length);
            updateStatusDisplay(d.solve_status, d.solve_time);

            // Show/hide rate limit warning
            if (rateLimitWarning) {
                rateLimitWarning.style.display = d.rate_limit_warning ? 'block' : 'none';
            }
        } catch (e) { }
    }, 1000);
});
